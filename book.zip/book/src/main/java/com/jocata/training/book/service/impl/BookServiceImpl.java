package com.jocata.training.book.service.impl;

import com.jocata.training.book.dao.BookDao;
import com.jocata.training.book.entity.Book;
import com.jocata.training.book.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    BookDao bookDao;

    @Override
    public Integer save(Book book) {
        Serializable id = bookDao.save(book);
        if (id != null) {
            return (Integer) id;
        } else
            return null;
    }

    @Override
    public void udate(Book book) {
        bookDao.udate(book);
    }

    @Override
    public void delete(Book book) {
        bookDao.delete(book);
    }

    @Override
    public void saveWithId(Book book) {
       bookDao.saveWithId(book);
    }

    @Override
    public Book getEntityById(int id) {
        Book book = bookDao.getEntityById(Book.class, id);
        if (book != null) {
            return book;
        } else
            return null;
    }

    @Override
    public List<Book> loadEntityByHql() {
        List<Book> books = bookDao.loadEntityByHql(" from Book");
        if (books != null) {
            return books;
        } else
            return null;
    }

    @Override
    public List<Book> loadBookByName(String name) {
        List<Book> books = bookDao.loadEntityByHql("from Book where b.bookname ='" + name + "'");
        if (books != null) {
            return books;
        } else
            return null;
    }

    @Override
    public Long loadMaxId() {
        Long Id = Long.valueOf(bookDao.loadEntityByHql("select  max(Id) from Book").get(0).toString());
        bookDao.saveWithId(Book.class);
        return Id;
    }
}
