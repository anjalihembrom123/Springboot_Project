package com.jocata.training.book.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "book")
public class Book {

    @Id
    //@GeneratedValue
    private int Id;
    private String bookname;
    private String bookcatigory;

    public int getId() {
        return Id;
    }

    public Integer setId(int id) {
        Id = id;
        return null;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getBookcatigory() {
        return bookcatigory;
    }

    public void setBookcatigory(String bookcatigory) {
        this.bookcatigory = bookcatigory;
    }
}
