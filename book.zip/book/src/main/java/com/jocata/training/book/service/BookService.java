package com.jocata.training.book.service;

import com.jocata.training.book.entity.Book;
import org.springframework.data.jpa.repository.Query;

import java.io.Serializable;
import java.util.List;

public interface BookService {
    public  Integer save(Book book);

    public void udate(Book book);

    public void delete(Book book);
    public void saveWithId(Book book);

    public Book getEntityById( int id) ;

    public List<Book> loadEntityByHql();
    public List<Book> loadBookByName(String name);
    public Long loadMaxId();
}
