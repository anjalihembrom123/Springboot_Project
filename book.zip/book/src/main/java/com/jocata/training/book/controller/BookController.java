package com.jocata.training.book.controller;

import com.jocata.training.book.entity.Book;
import com.jocata.training.book.service.BookService;
import com.jocata.training.book.vo.BookReqRes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@RestController
public class BookController {
    @Autowired
    Book book;
    @Autowired
    BookService bookService;

    @Autowired
    BookReqRes bookReqRes;

    @PostMapping("/saveBook")
    public ResponseEntity<?> saveBookDetails(@RequestBody BookReqRes request) {
        BookReqRes response = request;
        Long maxId = bookService.loadMaxId();
        Integer Id = maxId.intValue();
        //book.setId(Id+1);
        book.setBookname(request.getBookname());
        book.setBookcatigory(request.getBookcatigory());
        book.setId(Id+1);
         //Integer pkId = (Integer) bookService.save(book);
        bookService.saveWithId(book);

        response.setId(book.getId());
        return new ResponseEntity<BookReqRes>(response, HttpStatus.OK);
//        if (bId > 0) {
//            book.setId(bId);
//            response.setId(book.getId());
////            response.setBookname(book.getBookname());
////            response.setBookcatigory(book.getBookcatigory());
//            return new ResponseEntity<BookReqRes>(response, HttpStatus.OK);
//        } else {
//            return new ResponseEntity<String>("Error Saving Book Details", HttpStatus.BAD_REQUEST);
//        }
    }

    @GetMapping("/getBookById")
    public ResponseEntity<?> getBookById(@RequestBody BookReqRes request) {
        book = bookService.getEntityById(request.getId());
        if (book != null) {
            bookReqRes.setId(book.getId());
            bookReqRes.setBookname(book.getBookname());
            bookReqRes.setBookcatigory(book.getBookcatigory());
            return new ResponseEntity<BookReqRes>(bookReqRes, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Currently no book available in this name in table", HttpStatus.OK);
        }
    }
    @GetMapping("/allBooks")
    public ResponseEntity<?> getAllBooks() {
        List<Book> bookList = bookService.loadEntityByHql();

        if (bookList.size() > 0) {
            return new ResponseEntity<List<Book>>(bookList, HttpStatus.OK);
        } else
            return new ResponseEntity<String>("No Users exists in the database", HttpStatus.BAD_REQUEST);
    }
    @GetMapping("/getBookByName")
    public ResponseEntity<?> getBookByName(@RequestBody BookReqRes request) {
        List<Book> bookList = bookService.loadBookByName(request.getBookname());
        List<BookReqRes> response = new ArrayList<>();

        if (bookList != null) {
            for (Book book1 : bookList) {
                BookReqRes bk = new BookReqRes();
                bk.setId(book1.getId());
                response.add(bk);
            }
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Currently no book available in this name in table", HttpStatus.OK);
        }
    }
    @GetMapping("/maxId")
    public ResponseEntity<?> getMaxId() {
        return new ResponseEntity<>(bookService.loadMaxId(), HttpStatus.OK);
    }
}
