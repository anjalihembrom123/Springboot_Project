package com.jocata.training.book.dao;

import com.jocata.training.book.entity.Book;
import org.hibernate.Session;
import org.springframework.data.jpa.repository.Query;

import java.io.Serializable;
import java.util.List;

public interface BookDao {
    public <T> Serializable save(T entity);

    public <T> void udate(T entity);

    public <T> void delete(T entity);
    public <T> void saveWithId(T entity);

    public <T> T getEntityById(Class<T> T,int id) ;

    public <T> List<T> loadEntityByHql(String hql);

}
