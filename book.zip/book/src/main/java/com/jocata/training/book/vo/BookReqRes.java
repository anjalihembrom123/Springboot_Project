package com.jocata.training.book.vo;

import org.springframework.stereotype.Component;

@Component
public class BookReqRes {
    private int Id;
    private String bookname;
    private String bookcatigory;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getBookcatigory() {
        return bookcatigory;
    }

    public void setBookcatigory(String bookcatigory) {
        this.bookcatigory = bookcatigory;
    }
}
