package com.jocata.training.book.dao.impl;

import com.jocata.training.book.dao.BookDao;
import com.jocata.training.book.entity.Book;
import com.jocata.training.book.utils.HibernateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;

@Component
public class BookDaoImpl implements BookDao {
    @Autowired
    HibernateUtils hibernateUtils;
    @Override
    public <T> Serializable save(T entity) {
        return hibernateUtils.save(entity);
    }

    @Override
    public <T> void udate(T entity) {
        hibernateUtils.udate(entity);
    }

    @Override
    public <T> void delete(T entity) {
        hibernateUtils.delete(entity);
    }

    @Override
    public <T> void saveWithId(T entity) {
        hibernateUtils.saveWithId(entity);
    }

    @Override
    public <T> T getEntityById(Class<T> T, int id) {
        return hibernateUtils.getEntityById(T, id);
    }

    @Override
    public <T> List<T> loadEntityByHql(String hql) {
        return hibernateUtils.loadEntityByHql(hql);
    }

}
